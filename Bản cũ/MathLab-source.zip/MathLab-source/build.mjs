import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

const read = (path) => readFileSync(new URL(path, import.meta.url), 'utf8');
const output = resolve(process.argv[2] ?? 'dist/MathLab.html');
const styleTag = '<link rel="stylesheet" href="./src/styles.css">';
const scriptTag = '<script type="module" src="./src/app.js"></script>';
const template = read('index.html');

if (!template.includes(styleTag) || !template.includes(scriptTag)) {
  throw new Error('Không tìm thấy vị trí chèn CSS hoặc JavaScript trong index.html.');
}

// The standalone build places these three modules in a single private scope.
const modules = ['catalog.js', 'math.js', 'app.js'].map((name) =>
  read('src/' + name)
    .replace(/^import \{ [^\n]+ \} from '\.\/(?:catalog|math)\.js';\n/gm, '')
    .replace(/^export \{ [^\n]+ \};\n/gm, '')
    .trim()
);
const script = modules.join('\n\n').replace(/<\/script/gi, '<\\/script');
const styles = read('src/styles.css');
const html = template
  .replace(styleTag, () => '<style>\n' + styles + '</style>')
  .replace(scriptTag, () => '<script>\n(function () {\n"use strict";\n' + script + '\n})();\n</script>');

mkdirSync(dirname(output), { recursive: true });
writeFileSync(output, html);
console.log(output);
