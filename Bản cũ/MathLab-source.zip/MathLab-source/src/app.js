import { categories, icons, formulas, tools } from './catalog.js';
import { numeric, positive, whole, gcd, factorial, choose, evalExpr } from './math.js';

var state={page:'home',grade:'all',cat:'all',query:'',tool:'expression',favs:[]};
try{state.favs=JSON.parse(localStorage.getItem('mathlab-favs-v1')||'[]');if(!Array.isArray(state.favs))state.favs=[];}catch(e){state.favs=[];}
var app=document.getElementById('app'),search=document.getElementById('search-input');
function esc(s){return String(s===undefined?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function fmt(n){if(typeof n==='string')return n;if(!Number.isFinite(n))return 'Không xác định';if(n!==0&&(Math.abs(n)>=1e13||Math.abs(n)<1e-8))return n.toExponential(7);return new Intl.NumberFormat('vi-VN',{maximumFractionDigits:9}).format(Number(n.toPrecision(12)));}
function activeNav(){document.querySelectorAll('[data-view]').forEach(function(el){el.classList.toggle('active',el.dataset.view===state.page);});document.querySelectorAll('[data-grade]').forEach(function(el){el.classList.toggle('active',el.dataset.grade===state.grade);});document.getElementById('top-title').textContent={home:'Tổng quan',formulas:'Thư viện công thức',tools:'Công cụ tính toán',favorites:'Đã lưu'}[state.page];}
function show(page){state.page=page;render();window.scrollTo(0,0);}
function boxCard(t){return '<button class="tool-card" data-tool="'+t.id+'"><i>'+esc(t.icon)+'</i><strong>'+esc(t.title)+'</strong><small>'+esc(t.desc)+'</small></button>';}
function home(){var top=['expression','quadratic','geometry','coordinate','statistics','graph'];app.innerHTML='<section class="hero"><div><span class="eyebrow">NỀN TẢNG TOÁN HỌC TRỰC QUAN</span><h1>Khám phá Toán học<br>theo cách thông minh hơn.</h1><p>Tra cứu công thức nhanh chóng, tính toán ngay trên trình duyệt, giao diện tối giản và dễ sử dụng.</p><button class="btn white" data-view="formulas">∑ Thư viện công thức</button><button class="btn ghost" data-view="tools">▦ Mở công cụ</button></div></section>'+
'<div class="stats"><div class="stat"><i class="stat-icon">∑</i><div><strong>'+formulas.length+'</strong><small>Công thức</small></div></div><div class="stat"><i class="stat-icon">⌘</i><div><strong>'+tools.length+'</strong><small>Công cụ</small></div></div><div class="stat"><i class="stat-icon">▤</i><div><strong>7</strong><small>Khối lớp 6–12</small></div></div><div class="stat"><i class="stat-icon">◈</i><div><strong>'+categories.length+'</strong><small>Chuyên đề</small></div></div></div>'+
'<div class="section-head"><div><h2>Khám phá theo chuyên đề</h2><p>Chọn nhóm kiến thức để tra cứu</p></div><button class="link-button" data-view="formulas">Xem tất cả ›</button></div><div class="groups">'+categories.map(function(c,i){return '<button class="group-card" data-category="'+esc(c)+'"><i>'+icons[i]+'</i><strong>'+esc(c)+'</strong><small>'+formulas.filter(function(f){return f.group===c;}).length+' công thức</small></button>';}).join('')+'</div>'+
'<div class="section-head"><div><h2>Công cụ nổi bật</h2><p>Nhập dữ liệu để nhận kết quả ngay</p></div><button class="link-button" data-view="tools">Tất cả công cụ ›</button></div><div class="tool-cards">'+top.map(function(id){return boxCard(tools.find(function(t){return t.id===id;}));}).join('')+'</div>';
}
function normalizeSearch(value) {
  return value.toLowerCase().normalize('NFD').replace(/\p{M}/gu, '').replace(/đ/g, 'd').trim();
}

function matchesGrade(f){if(state.grade==='all')return true;var g=Number(state.grade),p=f.grades.split('-').map(Number);return g>=p[0]&&g<=p[p.length-1];}
function listFormulas(fav){var q=normalizeSearch(state.query);return formulas.filter(function(f){return (!fav||state.favs.indexOf(f.id)!==-1)&&matchesGrade(f)&&(state.cat==='all'||f.group===state.cat)&&(!q||normalizeSearch(f.title+' '+f.group+' '+f.expr+' '+f.note).includes(q));});}
function formulaCard(f){return '<article class="formula"><div class="meta"><span class="tag">'+esc(f.group)+'</span><span class="f-grade">Lớp '+esc(f.grades)+'</span></div><h3>'+esc(f.title)+'</h3><div class="expr">'+esc(f.expr)+'</div><p class="note">'+esc(f.note)+'</p><div class="f-actions"><button data-copy="'+f.id+'">⧉ Sao chép</button><button class="heart '+(state.favs.includes(f.id)?'on':'')+'" data-fav="'+f.id+'" aria-label="Lưu công thức">'+(state.favs.includes(f.id)?'♥':'♡')+'</button></div></article>';}
function formulaPage(fav){var items=listFormulas(fav);app.innerHTML='<div class="page-title"><div><h1>'+(fav?'Công thức đã lưu':'Thư viện công thức')+'</h1><p>Tìm nhanh các công thức Toán phổ thông theo chuyên đề và khối lớp.</p></div><span class="pill">'+items.length+' công thức</span></div>'+
'<div class="filters">'+['all'].concat(categories).map(function(c){return '<button class="chip '+(state.cat===c?'active':'')+'" data-cat="'+esc(c)+'">'+(c==='all'?'Tất cả chủ đề':esc(c))+'</button>';}).join('')+'</div>'+
'<div class="filters">'+['all','6','7','8','9','10','11','12'].map(function(g){return '<button class="chip '+(state.grade===g?'active':'')+'" data-grade="'+g+'">'+(g==='all'?'Tất cả lớp':'Lớp '+g)+'</button>';}).join('')+'</div>'+
(items.length?'<div class="formula-grid">'+items.map(formulaCard).join('')+'</div>':'<div class="empty"><strong>Không tìm thấy công thức phù hợp</strong><p>Đổi từ khóa hoặc bộ lọc rồi thử lại.</p><button class="btn outline" data-reset="1">Xóa bộ lọc</button></div>');
}
function field(k,label,v,type){type=type||'number';return '<div class="field '+(type==='textarea'||type==='text'?'wide':'')+'"><label for="f-'+k+'">'+esc(label)+'</label>'+(type==='textarea'?'<textarea id="f-'+k+'" data-key="'+k+'">'+esc(v)+'</textarea>':'<input id="f-'+k+'" data-key="'+k+'" type="'+(type==='text'?'text':'number')+'" step="any" value="'+esc(v)+'">')+'</div>';}
function choice(k,label,options){return '<div class="field"><label>'+esc(label)+'</label><select data-key="'+k+'">'+options.map(function(o){return '<option value="'+esc(o[0])+'">'+esc(o[1])+'</option>';}).join('')+'</select></div>';}
function form(id){
var fields='',help='';
if(id==='expression'){help='Hỗ trợ +, −, ×, ÷, lũy thừa ^, sqrt(x), sin(x), cos(x), tan(x), log(x), ln(x), abs(x), π và e. Góc tính theo độ.';fields=field('expr','Biểu thức','2*(3+4)^2 + sqrt(81)','text');}
if(id==='fraction'){help='Tử số và mẫu số phải là số nguyên; mẫu số khác 0.';fields=field('a','Tử số a',2)+field('b','Mẫu số b',3)+choice('op','Phép tính',[['+','Cộng'],['-','Trừ'],['*','Nhân'],['/','Chia']])+field('c','Tử số c',1)+field('d','Mẫu số d',4);}
if(id==='percent'){fields=choice('mode','Loại phép tính',[['of','p% của x'],['ratio','a là bao nhiêu % của b'],['change','Tăng/giảm từ a sang b']])+field('a','Giá trị a hoặc p',20)+field('b','Giá trị b hoặc x',250);}
if(id==='linear'){help='Giải ax+b=0.';fields=field('a','Hệ số a',3)+field('b','Hệ số b',-12);}
if(id==='quadratic'){help='Giải ax²+bx+c=0 trong tập số thực.';fields=field('a','Hệ số a',1)+field('b','Hệ số b',-5)+field('c','Hệ số c',6);}
if(id==='system'){help='Hệ a₁x+b₁y=c₁, a₂x+b₂y=c₂.';fields=field('a1','Hệ số a₁',2)+field('b1','Hệ số b₁',1)+field('c1','Hằng số c₁',5)+field('a2','Hệ số a₂',1)+field('b2','Hệ số b₂',-1)+field('c2','Hằng số c₂',1);}
if(id==='geometry'){help='Nhập độ dài các đại lượng theo cùng một đơn vị; ô không dùng sẽ được bỏ qua.';fields=choice('shape','Hình cần tính',[['rectangle','Hình chữ nhật'],['square','Hình vuông'],['triangle','Tam giác'],['parallelogram','Hình bình hành'],['trapezoid','Hình thang'],['rhombus','Hình thoi'],['circle','Hình tròn']])+field('a','Cạnh a / đáy a',6)+field('b','Cạnh b / đáy b',4)+field('h','Chiều cao h',3)+field('r','Bán kính r',5);}
if(id==='solid'){help='Khối hình nón là nón tròn xoay; khối chóp có đáy chữ nhật và chiều cao vuông góc đáy.';fields=choice('shape','Loại khối',[['cube','Lập phương'],['box','Hộp chữ nhật'],['cylinder','Hình trụ'],['cone','Hình nón'],['sphere','Hình cầu'],['pyramid','Chóp đáy chữ nhật']])+field('a','Cạnh a',4)+field('b','Cạnh b',3)+field('h','Chiều cao h',6)+field('r','Bán kính r',3);}
if(id==='pythag'){fields=choice('mode','Biết hai cạnh',[['ab','Hai cạnh góc vuông a, b'],['ac','Cạnh góc vuông a và cạnh huyền c']])+field('a','Độ dài a',3)+field('b','Độ dài b hoặc c',4);}
if(id==='coordinate'){fields=field('x1','x₁',1)+field('y1','y₁',2)+field('x2','x₂',5)+field('y2','y₂',10);}
if(id==='statistics'){help='Dùng dấu chấm cho phần thập phân. Ngăn cách số bằng dấu chấm phẩy hoặc khoảng trắng.';fields=field('series','Dãy dữ liệu','2; 4; 4; 4; 5; 5; 7; 9','textarea');}
if(id==='combination'){fields=field('n','Số phần tử n',6)+field('k','Số chọn k',2)+field('p','Xác suất p (0–1)',.5);}
if(id==='trig'){fields=field('angle','Góc tính bằng độ',30);}
if(id==='logarithm'){fields=field('a','Cơ số a',2)+field('x','Giá trị x',8);}
if(id==='graph'){help='Vẽ trên miền x từ −10 đến 10, tỉ lệ trục y điều chỉnh tự động.';fields=choice('mode','Kiểu hàm',[['quadratic','Bậc hai: y=ax²+bx+c'],['linear','Bậc nhất: y=ax+b']])+field('a','a',1)+field('b','b',-2)+field('c','c',-3);}
if(id==='number'){fields=field('n','Số nguyên dương n',84)+field('m','Số nguyên dương m',30);}
if(id==='unit'){fields=choice('group','Đại lượng',[['length','Độ dài'],['area','Diện tích'],['volume','Thể tích'],['mass','Khối lượng'],['time','Thời gian'],['angle','Góc']])+field('value','Giá trị',100)+'<div class="field"><label>Đơn vị nguồn</label><select id="unit-from" data-key="from"></select></div><div class="field"><label>Đơn vị đích</label><select id="unit-to" data-key="to"></select></div>';}
if(id==='time'){help='Nếu kết thúc sớm hơn bắt đầu thì tính sang ngày kế tiếp. Hai thời điểm giống nhau được tính là 0 phút.';fields=field('start','Bắt đầu (HH:mm)','08:15','text')+field('end','Kết thúc (HH:mm)','11:45','text');}
return '<p class="calc-note">'+esc(help)+'</p><div class="fields">'+fields+'</div><button class="btn blue" type="submit">Tính kết quả →</button>';
}
var units={length:{mm:.001,cm:.01,m:1,km:1000,inch:.0254,ft:.3048},area:{'mm²':.000001,'cm²':.0001,'m²':1,'km²':1e6,ha:1e4},volume:{mL:.001,L:1,'cm³':.001,'dm³':1,'m³':1000},mass:{mg:.001,g:1,kg:1000,'tấn':1e6},time:{'giây':1,'phút':60,'giờ':3600,'ngày':86400},angle:{'độ':1,'radian':180/Math.PI}};
function updateUnits(){var group=document.querySelector('[data-key="group"]').value;var names=Object.keys(units[group]);['unit-from','unit-to'].forEach(function(id,i){var el=document.getElementById(id);el.innerHTML=names.map(function(u){return '<option value="'+esc(u)+'">'+esc(u)+'</option>';}).join('');el.value=names[Math.min(i+1,names.length-1)];});}
function renderTools(){
var q=normalizeSearch(state.query),list=tools.filter(function(t){return !q||normalizeSearch(t.title+' '+t.desc).includes(q);});
if(list.length&&!list.some(function(t){return t.id===state.tool;}))state.tool=list[0].id;
var t=tools.find(function(z){return z.id===state.tool;});
app.innerHTML='<div class="page-title"><div><h1>Bộ công cụ tính toán</h1><p>Chọn công cụ, nhập dữ liệu, nhận kết quả trực tiếp.</p></div><span class="pill">'+list.length+' công cụ</span></div>'+
(!list.length?'<div class="empty"><strong>Không tìm thấy công cụ</strong><button class="btn outline" data-reset="1">Xóa tìm kiếm</button></div>':
'<div class="tools-layout"><nav class="tool-menu" aria-label="Danh mục công cụ">'+list.map(function(t){return '<button class="'+(t.id===state.tool?'active':'')+'" data-tool="'+t.id+'"><i>'+esc(t.icon)+'</i>'+esc(t.title)+'</button>';}).join('')+'</nav><section class="panel"><div class="panel-head"><div class="panel-icon">'+esc(t.icon)+'</div><div><h2>'+esc(t.title)+'</h2><p>'+esc(t.desc)+'</p></div></div><form id="calc-form">'+form(t.id)+'</form><div id="calc-output" aria-live="polite"></div>'+(t.id==='graph'?'<div class="graphbox"><canvas width="880" height="450" id="plot" aria-label="Đồ thị hàm số"></canvas></div>':'')+'</section></div>');
if(list.length){var f=document.getElementById('calc-form');f.addEventListener('submit',function(e){e.preventDefault();calculate();});if(t.id==='unit'){updateUnits();f.querySelector('[data-key="group"]').addEventListener('change',function(){updateUnits();calculate();});}if(t.id==='graph')f.addEventListener('change',calculate);calculate();}
}
function render(){activeNav();if(state.page==='home')home();else if(state.page==='tools')renderTools();else formulaPage(state.page==='favorites');}
function values(){var o={};document.querySelectorAll('#calc-form [data-key]').forEach(function(el){o[el.dataset.key]=el.value;});return o;}
function output(main,rows,note){var el=document.getElementById('calc-output');if(!el)return;el.innerHTML='<div class="output"><small>KẾT QUẢ TÍNH TOÁN</small><h3>'+esc(main)+'</h3>'+(rows||[]).map(function(p){return '<div class="row"><span>'+esc(p[0])+'</span><b>'+esc(p[1])+'</b></div>';}).join('')+(note?'<p class="calc-note">'+esc(note)+'</p>':'')+'</div>';}
function err(s){var el=document.getElementById('calc-output');if(el)el.innerHTML='<div class="output error"><small>THÔNG BÁO</small><h3>'+esc(s)+'</h3></div>';}
function calculate(){try{
var v=values(),N=function(k){return numeric(v[k],k);},a,b,c,d,h,r,n,m,D;
switch(state.tool){
case 'expression':output(fmt(evalExpr(v.expr)),[['Biểu thức',v.expr]],'Sin, cos, tan tính theo độ.');break;
case 'fraction':
a=whole(N('a'),'a');b=whole(N('b'),'b');c=whole(N('c'),'c');d=whole(N('d'),'d');
if(b===0||d===0)throw Error('Mẫu số không được bằng 0');
var t,u;if(v.op==='+'){t=a*d+c*b;u=b*d;}else if(v.op==='-'){t=a*d-c*b;u=b*d;}else if(v.op==='*'){t=a*c;u=b*d;}else{if(c===0)throw Error('Không được chia cho phân số 0');t=a*d;u=b*c;}
if(!Number.isSafeInteger(t)||!Number.isSafeInteger(u))throw Error('Phân số vượt giới hạn số nguyên chính xác');
if(u<0){u=-u;t=-t;}var g=gcd(t,u)||1;output(fmt(t/g)+'/'+fmt(u/g),[['Dạng thập phân',fmt(t/u)],['Rút gọn',fmt(t/g)+'/'+fmt(u/g)]]);break;
case 'percent':
a=N('a');b=N('b');if(v.mode==='of')output(fmt(a*b/100),[['Công thức','a × b / 100']]);else if(v.mode==='ratio'){if(!b)throw Error('Mẫu số b phải khác 0');output(fmt(a/b*100)+'%');}else{if(a===0)throw Error('Giá trị ban đầu phải khác 0');var pct=(b-a)/Math.abs(a)*100;output(fmt(pct)+'%',[['Thay đổi tuyệt đối',fmt(b-a)],['Chiều thay đổi',pct>=0?'Tăng':'Giảm']]);}break;
case 'linear':a=N('a');b=N('b');output(a===0?(b===0?'Vô số nghiệm':'Vô nghiệm'):'x = '+fmt(-b/a),[['Công thức','ax+b=0']]);break;
case 'quadratic':
a=N('a');b=N('b');c=N('c');if(a===0){output(b===0?(c===0?'Vô số nghiệm':'Vô nghiệm'):'x = '+fmt(-c/b),[['Loại','Phương trình bậc nhất']]);break;}
D=b*b-4*a*c;if(D<0)output('Không có nghiệm thực',[['Δ',fmt(D)]]);else if(D===0)output('x = '+fmt(-b/(2*a)),[['Δ','0'],['Loại','Nghiệm kép']]);else{var z=Math.sqrt(D);output('x₁ = '+fmt((-b+z)/(2*a)),[['x₂',fmt((-b-z)/(2*a))],['Δ',fmt(D)]]);}break;
case 'system':
var a1=N('a1'),b1=N('b1'),c1=N('c1'),a2=N('a2'),b2=N('b2'),c2=N('c2');D=a1*b2-a2*b1;var dx=c1*b2-c2*b1,dy=a1*c2-a2*c1;var near=function(x){return Math.abs(x)<1e-12;};
if(near(D))output(near(dx)&&near(dy)?'Vô số nghiệm':'Vô nghiệm',[['Định thức D',fmt(D)]]);else output('x = '+fmt(dx/D),[['y',fmt(dy/D)],['Định thức D',fmt(D)]]);break;
case 'geometry':
var sh=v.shape;var P=function(k){return positive(N(k),k);};var rows=[],S=0;
if(sh==='rectangle'){a=P('a');b=P('b');S=a*b;rows=[['Chu vi',fmt(2*(a+b))]];}
if(sh==='square'){a=P('a');S=a*a;rows=[['Chu vi',fmt(4*a)]];}
if(sh==='triangle'){a=P('a');h=P('h');S=a*h/2;}
if(sh==='parallelogram'){a=P('a');h=P('h');S=a*h;}
if(sh==='trapezoid'){a=P('a');b=P('b');h=P('h');S=(a+b)*h/2;}
if(sh==='rhombus'){a=P('a');h=P('h');S=a*h;rows=[['Chu vi',fmt(4*a)]];}
if(sh==='circle'){r=P('r');S=Math.PI*r*r;rows=[['Chu vi',fmt(2*Math.PI*r)]];}
output('S = '+fmt(S),rows,'Diện tích theo đơn vị².');break;
case 'solid':
var sf=v.shape;var P2=function(k){return positive(N(k),k);};var V=0,A=null;
if(sf==='cube'){a=P2('a');V=a*a*a;A=6*a*a;}
if(sf==='box'){a=P2('a');b=P2('b');h=P2('h');V=a*b*h;A=2*(a*b+a*h+b*h);}
if(sf==='cylinder'){r=P2('r');h=P2('h');V=Math.PI*r*r*h;A=2*Math.PI*r*(r+h);}
if(sf==='cone'){r=P2('r');h=P2('h');V=Math.PI*r*r*h/3;A=Math.PI*r*(r+Math.hypot(r,h));}
if(sf==='sphere'){r=P2('r');V=4*Math.PI*r*r*r/3;A=4*Math.PI*r*r;}
if(sf==='pyramid'){a=P2('a');b=P2('b');h=P2('h');V=a*b*h/3;}
output('V = '+fmt(V),A===null?[]:[['Diện tích toàn phần',fmt(A)]],'Thể tích theo đơn vị³.');break;
case 'pythag':a=positive(N('a'),'a');b=positive(N('b'),'b');if(v.mode==='ab')output('c = '+fmt(Math.hypot(a,b)),[['Công thức','c=√(a²+b²)']]);else{if(b<=a)throw Error('Cạnh huyền c phải lớn hơn a');output('b = '+fmt(Math.sqrt((b-a)*(b+a))),[['Công thức','b=√(c²−a²)']]);}break;
case 'coordinate':
var x1=N('x1'),y1=N('y1'),x2=N('x2'),y2=N('y2'),ddx=x2-x1,ddy=y2-y1;
output('AB = '+fmt(Math.hypot(ddx,ddy)),[['Trung điểm','('+fmt((x1+x2)/2)+'; '+fmt((y1+y2)/2)+')'],['Hệ số góc',ddx===0?'Không xác định':fmt(ddy/ddx)],['Phương trình đường thẳng',ddx===0?'x='+fmt(x1):'y−('+fmt(y1)+')='+fmt(ddy/ddx)+'(x−('+fmt(x1)+'))']]);break;
case 'statistics':
var items=v.series.trim().split(/[;\s]+/).filter(Boolean);if(items.length<1||items.length>2000)throw Error('Cần từ 1 tới 2000 số');var nums=items.map(function(s){return numeric(s,'phần tử');}),sorted=nums.slice().sort(function(x,y){return x-y;}),length=nums.length,sum=nums.reduce(function(p,q){return p+q;},0),avg=sum/length,median=length%2?sorted[(length-1)/2]:(sorted[length/2-1]+sorted[length/2])/2,variance=nums.reduce(function(p,q){return p+(q-avg)*(q-avg);},0)/length;
output('x̄ = '+fmt(avg),[['Số phần tử',length],['Trung vị',fmt(median)],['Phương sai tổng thể',fmt(variance)],['Độ lệch chuẩn tổng thể',fmt(Math.sqrt(variance))],['Giá trị nhỏ nhất',fmt(sorted[0])],['Giá trị lớn nhất',fmt(sorted[length-1])]]);break;
case 'combination':
n=whole(N('n'),'n');var k=whole(N('k'),'k');var p=N('p');if(n<0||k<0||k>n||n>250)throw Error('Yêu cầu 0 ≤ k ≤ n ≤ 250');if(p<0||p>1)throw Error('Xác suất p phải từ 0 đến 1');var co=choose(n,k);output('C(n,k) = '+co.toString(),[['n!',factorial(n).toString()],['A(n,k)',(co*factorial(k)).toString()],['P(X=k)',fmt(Number(co)*Math.pow(p,k)*Math.pow(1-p,n-k))]]);break;
case 'trig':a=N('angle');r=a*Math.PI/180;var s=Math.sin(r),cs=Math.cos(r);output('sin α = '+fmt(s),[['cos α',fmt(cs)],['tan α',Math.abs(cs)<1e-12?'Không xác định':fmt(s/cs)],['Radian',fmt(r)]]);break;
case 'logarithm':a=N('a');var x=N('x');if(a<=0||a===1||x<=0)throw Error('Điều kiện: a>0, a≠1, x>0');output('logₐx = '+fmt(Math.log(x)/Math.log(a)),[['ln x',fmt(Math.log(x))],['log₁₀x',fmt(Math.log10(x))],['aˣ',fmt(Math.pow(a,x))],['√x',fmt(Math.sqrt(x))]]);break;
case 'graph':a=N('a');b=N('b');c=N('c');var line=v.mode==='linear';output(line?'y='+fmt(a)+'x + ('+fmt(b)+')':'y='+fmt(a)+'x² + ('+fmt(b)+')x + ('+fmt(c)+')',line?[['Hệ số góc',fmt(a)]]:a===0?[['Lưu ý','Đường thẳng hoặc hàm hằng']]:[['Đỉnh I','('+fmt(-b/(2*a))+'; '+fmt(c-b*b/(4*a))+')']]);drawGraph(a,b,c,line);break;
case 'number':
n=whole(N('n'),'n');m=whole(N('m'),'m');if(n<1||m<1||n>1000000000||m>1000000000)throw Error('Chỉ nhận số nguyên dương ≤ 1.000.000.000');var factor=[],z=n;for(var j=2;j*j<=z;j+=(j===2?1:2)){if(z%j===0){var power=0;while(z%j===0){z/=j;power++;}factor.push(j+(power>1?'^'+power:''));}}if(z>1)factor.push(String(z));var gg=gcd(n,m);
output('ƯCLN = '+fmt(gg),[['BCNN',fmt(n/gg*m)],['Thừa số nguyên tố',n===1?'1':factor.join(' × ')],['Số chính phương?',Number.isInteger(Math.sqrt(n))?'Có':'Không']]);break;
case 'unit':var map=units[v.group];if(!map||map[v.from]===undefined||map[v.to]===undefined)throw Error('Đơn vị chưa hợp lệ');output(fmt(N('value')*map[v.from]/map[v.to])+' '+v.to,[['Đầu vào',fmt(N('value'))+' '+v.from]]);break;
case 'time':
var parse=function(s){var ma=/^(\d{1,2}):(\d{2})$/.exec(s);if(!ma||+ma[1]>23||+ma[2]>59)throw Error('Thời gian cần ở dạng HH:mm (00:00–23:59)');return +ma[1]*60+(+ma[2]);};var t1=parse(v.start),t2=parse(v.end),dt=(t2-t1+1440)%1440,hr=(t1/60%12)*30,mn=t1%60*6,ang=Math.abs(hr-mn);
output(Math.floor(dt/60)+' giờ '+dt%60+' phút',[['Tổng thời gian',dt+' phút'],['Góc nhỏ hai kim lúc bắt đầu',fmt(Math.min(ang,360-ang))+'°']]);break;
}
}catch(e){err(e.message||'Không thể tính kết quả');}}
function drawGraph(a,b,c,linear){
var canvas=document.getElementById('plot');if(!canvas)return;var ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;
ctx.clearRect(0,0,w,h);ctx.fillStyle='#fff';ctx.fillRect(0,0,w,h);
var fun=function(x){return linear?a*x+b:a*x*x+b*x+c;},maxY=0;
for(var i=-10;i<=10;i+=.2){var value=fun(i);if(Number.isFinite(value))maxY=Math.max(maxY,Math.abs(value));}
var ymax=Math.max(8,Math.min(10000,maxY*1.12));var px=function(x){return (x+10)/20*w;},py=function(y){return h/2-y/ymax*h/2;};
ctx.strokeStyle='#edf1f8';ctx.lineWidth=1;for(var x=-10;x<=10;x+=2){ctx.beginPath();ctx.moveTo(px(x),0);ctx.lineTo(px(x),h);ctx.stroke();}
for(var yy=-4;yy<=4;yy++){var yval=yy*ymax/4;ctx.beginPath();ctx.moveTo(0,py(yval));ctx.lineTo(w,py(yval));ctx.stroke();}
ctx.strokeStyle='#a0afcb';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(px(0),0);ctx.lineTo(px(0),h);ctx.moveTo(0,py(0));ctx.lineTo(w,py(0));ctx.stroke();
ctx.font='14px sans-serif';ctx.fillStyle='#8795af';ctx.fillText('y',px(0)+10,17);ctx.fillText('x',w-18,Math.max(18,Math.min(h-10,py(0)-9)));
ctx.beginPath();ctx.strokeStyle='#5066d2';ctx.lineWidth=4;ctx.lineCap='round';var drawing=false;
for(var k=0;k<=w;k++){var gx=-10+20*k/w,gy=py(fun(gx));if(!Number.isFinite(gy)||Math.abs(gy)>h*3){drawing=false;continue;}if(!drawing){ctx.moveTo(k,gy);drawing=true;}else ctx.lineTo(k,gy);}ctx.stroke();
}
function toast(msg){var old=document.querySelector('.toast');if(old)old.remove();var d=document.createElement('div');d.className='toast';d.textContent=msg;document.body.appendChild(d);setTimeout(function(){d.remove();},2300);}
function copyText(s){if(navigator.clipboard&&navigator.clipboard.writeText)return navigator.clipboard.writeText(s);var el=document.createElement('textarea');el.value=s;el.style.position='fixed';el.style.opacity='0';document.body.appendChild(el);el.select();var ok=document.execCommand('copy');el.remove();return ok?Promise.resolve():Promise.reject(new Error('Clipboard không khả dụng'));}
document.addEventListener('click',function(e){
var b=e.target.closest('button');if(!b)return;
if(b.dataset.view){state.page=b.dataset.view;state.query='';state.cat='all';search.value='';show(state.page);return;}
if(b.dataset.category){state.cat=b.dataset.category;state.page='formulas';state.query='';search.value='';render();return;}
if(b.dataset.tool){state.tool=b.dataset.tool;state.page='tools';state.query='';search.value='';render();return;}
if(b.dataset.grade){state.grade=b.dataset.grade;state.page='formulas';render();return;}
if(b.dataset.cat){state.cat=b.dataset.cat;render();return;}
if(b.dataset.reset){state.cat='all';state.grade='all';state.query='';search.value='';render();return;}
if(b.dataset.fav!==undefined){var id=Number(b.dataset.fav),p=state.favs.indexOf(id);if(p===-1)state.favs.push(id);else state.favs.splice(p,1);try{localStorage.setItem('mathlab-favs-v1',JSON.stringify(state.favs));}catch(e){}render();return;}
if(b.dataset.copy!==undefined){var f=formulas[Number(b.dataset.copy)];copyText(f.title+'\n'+f.expr+'\n'+f.note).then(function(){toast('Đã sao chép công thức');}).catch(function(){toast('Không thể sao chép');});}
});
document.getElementById('side-grades').innerHTML=['all','6','7','8','9','10','11','12'].map(function(g){return '<button data-grade="'+g+'" class="'+(g==='all'?'active':'')+'">'+(g==='all'?'Tất cả lớp':g)+'</button>';}).join('');
search.addEventListener('input',function(){state.query=search.value;if(state.page==='home')state.page='formulas';render();});
document.addEventListener('keydown',function(e){if(e.key==='/'&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName)){e.preventDefault();search.focus();}});
render();
