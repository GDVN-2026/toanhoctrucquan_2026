function numeric(x,label){if(x===undefined||String(x).trim()==='')throw Error('Thiếu giá trị '+label);var v=Number(x);if(!Number.isFinite(v))throw Error('Giá trị '+label+' không hợp lệ');return v;}
function positive(v,label){if(v<=0)throw Error(label+' phải lớn hơn 0');return v;}
function whole(v,label){if(!Number.isSafeInteger(v))throw Error(label+' phải là số nguyên trong giới hạn an toàn');return v;}
function gcd(a,b){a=Math.abs(a);b=Math.abs(b);while(b){var t=b;b=a%b;a=t;}return a;}
function factorial(n){var r=1n;for(var i=2n;i<=BigInt(n);i++)r*=i;return r;}
function choose(n,k){k=Math.min(k,n-k);var r=1n;for(var i=1;i<=k;i++)r=r*BigInt(n-k+i)/BigInt(i);return r;}

function evalExpr(input){
var s=String(input).replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-').replace(/π/g,'pi').replace(/\s+/g,'');
if(!s||s.length>160)throw Error('Biểu thức rỗng hoặc quá dài');
var i=0,steps=0,deg=Math.PI/180;
function tick(){if(++steps>1200)throw Error('Biểu thức quá phức tạp');}
function take(c){if(s.charAt(i)===c){i++;return true;}return false;}
function atom(){tick();
if(take('(')){var z=sum();if(!take(')'))throw Error('Thiếu dấu đóng ngoặc');return z;}
var m=s.slice(i).match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/);
if(m){i+=m[0].length;return Number(m[0]);}
m=s.slice(i).match(/^[a-zA-Z]+/);
if(m){i+=m[0].length;var name=m[0].toLowerCase();if(name==='pi')return Math.PI;if(name==='e')return Math.E;
if(!take('('))throw Error('Hàm '+name+' cần dấu ngoặc');var arg=sum();if(!take(')'))throw Error('Thiếu dấu đóng ngoặc');
var fs={sin:function(x){return Math.sin(x*deg);},cos:function(x){return Math.cos(x*deg);},tan:function(x){return Math.tan(x*deg);},sqrt:Math.sqrt,ln:Math.log,log:Math.log10,abs:Math.abs,exp:Math.exp};
if(!fs[name])throw Error('Hàm không hỗ trợ: '+name);return fs[name](arg);}
throw Error('Ký tự không hợp lệ tại vị trí '+(i+1));}
function pow(){var z=atom();if(take('^'))z=Math.pow(z,unary());return z;}
function unary(){if(take('+'))return unary();if(take('-'))return -unary();return pow();}
function product(){var z=unary();while(true){if(take('*'))z*=unary();else if(take('/'))z/=unary();else break;}return z;}
function sum(){var z=product();while(true){if(take('+'))z+=product();else if(take('-'))z-=product();else break;}return z;}
var ans=sum();if(i<s.length)throw Error('Biểu thức không đúng cú pháp');if(!Number.isFinite(ans))throw Error('Kết quả không xác định trong tập số thực');return ans;
}

export { numeric, positive, whole, gcd, factorial, choose, evalExpr };
