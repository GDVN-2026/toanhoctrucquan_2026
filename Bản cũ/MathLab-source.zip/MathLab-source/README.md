# MathLab · Toán học trực quan

- `index.html` chứa khung giao diện.
- `src/catalog.js` chứa danh mục công thức và công cụ. Giữ thứ tự các công thức hiện có vì mục đã lưu dùng chỉ số trong danh mục.
- `src/math.js` chứa bộ đọc biểu thức và các hàm tính toán dùng chung.
- `src/app.js` xử lý điều hướng, tìm kiếm, biểu mẫu và hiển thị kết quả.
- `src/styles.css` định dạng giao diện.

Để sửa và xem thử mã nguồn, mở thư mục qua một máy chủ HTTP tĩnh. Trang nguồn dùng mô-đun JavaScript.

Chạy `npm run build` trong thư mục này bằng Node.js để tạo `dist/MathLab.html`. Không cần cài thư viện. Mở file HTML đã build trực tiếp bằng trình duyệt để dùng ngoại tuyến.
